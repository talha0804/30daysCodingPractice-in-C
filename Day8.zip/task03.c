#include <stdio.h>
int main()
{
    int tries;
    int flag=0;
    printf("Enter the number of tries :");
    scanf("%d", &tries);
    printf("\n");
    for (int i = 0; i < tries; i++)
    {
    int size;
    printf("Enter the number of values:");
    scanf("%d", &size);
    int arr[size];
    printf("Enter %d Numbers : ", size);
    for (int i = 0; i < size; i++)
    {
        scanf("%d", &arr[i]);
    }
    
    for (int i = 0; i < size; i++)
    {
        if(arr[i]%2!=0){
            printf("Location of First odd integer:%d\n ", i+1);
            flag = 1;
            break;
        }
    }
    
    if (flag != 1)
    {
        printf("Location of First odd integer: 0");
    }
}
}
#include <iostream>
using namespace std;
#define rows 2
#define cols 2
int determinants(int arr[rows][cols])
{
    int i, j, d;
    cout << "Enter 2x2 matrix elements: " << endl;
    for (i = 0; i < rows; i++)
    {
        for (j = 0; j < cols; j++)
        {                     
            cin >> arr[i][j]; 
        }
   }
   for (i = 0; i < rows; i++)
   {
        for (j = 0; j < cols; j++)
        {                     
            d = arr[0][0] * arr[1][1] - arr[0][1] * arr[1][0];
        
        }
   }
   return d;
}
int main()
{
   int arr[rows][cols];
   cout << "Determinants:" << determinants(arr);
}
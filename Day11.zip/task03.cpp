#include <iostream>
using namespace std;
int secondMax(int arr[], int size)
{
    int max = 0;
    int smax = 0;
    int i;
    cout<< "Enter Array Elements:";
    for (i = 0; i < size; i++)
    {
        cin >> arr[i];
    }
    for (i = size - 1; i >= 0; i--)
    {
        if(arr[i]>max)
            max = arr[i];
        smax = max;
        if(arr[i]<smax){
            smax = arr[i];
            break;
        }
    }
    return smax;
}
int main()
{
    int size;
    cout << "Enter The Size of Array:";
    cin >> size;
    int arr[size];
    cout<<"The Second max:"<<secondMax(arr, size);
}
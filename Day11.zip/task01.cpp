#include<iostream>
using namespace std;
void reverse(int arr[],int size){
    int i;
    cout
        << "Enter Array Elements:";
    for ( i = 0; i < size;i++){
        cin >> arr[i];
    }
    cout << "Revrse Array:";
    for (i= size-1;i>=0;i--){
        cout << arr[i] << " ";
    }
}
int main(){
    int size;
    cout << "Enter The Size of Array:";
    cin >> size;
    int arr[size];
    reverse(arr, size);
}
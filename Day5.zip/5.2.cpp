#include <stdio.h>
#include <stdlib.h>

int main()
{
	int num,quotient,remainder,res=0,origNum;
	printf("Number:");
	scanf("%d",&num);
	origNum = num;
	while(num != 0 ){
		remainder = num % 10;
		res = res * 10 + remainder;
		num /= 10 ;
	}
	
	if(res==origNum)
		printf("Palindrome Number");
	else
		printf("Not A Palindrome Number");
	return 0;
}
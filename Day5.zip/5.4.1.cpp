#include <stdio.h>
#include <math.h>
int main()
{
	int num;
	printf("Enter Number:");
	scanf("%d",&num);
	int i = 0 ;
	while(i < num){
		for(int j = 0; j <= i; j++)
			printf("*");	
		printf("\n");
		i++;
	}
	return 0;
}

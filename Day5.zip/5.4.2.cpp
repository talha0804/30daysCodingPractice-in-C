#include <stdio.h>
int main()
{
	int num;
	printf("Enter Number:");
	scanf("%d",&num);
	int i = num ;
	while(i > 0){
		for(int j = i; j > 0; j--)
			printf("*");	
		printf("\n");
		i--;
	}
	return 0;
}




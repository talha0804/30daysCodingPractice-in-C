#include <stdio.h>
#include <math.h>
int main()
{
	int num,rem,res,resNum=0,orgNum;
	printf("Enter Number:");
	scanf("%d",&num);
	orgNum = num;
	while(num != 0){
		rem = num % 10;
		res = pow(rem,3);
		resNum += res;
		num /= 10;	
	}
	if( resNum == orgNum ){
		printf("Amstrong Number");
	}
	else{
		printf("Not A Amstrong Number");
	}
	return 0;
}

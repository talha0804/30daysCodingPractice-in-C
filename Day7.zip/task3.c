#include <stdio.h>
void swaping(int *a, int *b)
{  //a=9,b=5
    *a = *a + *b;//a=14
    *b=*a-*b;//b=9
    *a = *a - *b; // a=5;
    printf("After Swaping= A:%d B:%d\n", *a, *b);
}
int main()
{
    int a;
    int b;
    printf("Number 1:");
    scanf("%d", &a);
    printf("Number 2:");
    scanf("%d", &b);
    printf("Before Swaping= A:%d B:%d\n", a, b);
    swaping(&a, &b);

}
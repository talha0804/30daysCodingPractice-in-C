#include<stdio.h>
int main(){
    int num;
    printf("Number:");
    scanf("%d", &num);
    int *ptr=&num;
    printf("Adress of Varible:%p\n",&num);
    printf("Adress of Pointer In Hexadecimel:%p\n", &ptr);
    printf("Adress of Pointer In Octal:%o\n", &ptr);
    printf("Adress of Pointer In Decimal:%lu\n", &ptr);
}
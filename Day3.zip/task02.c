#include <stdio.h>
int main(){
    int a1,a2 ,a3;
    printf("Enter Three Angles of a Triangle=");
    scanf("%d %d %d", &a1, &a2, &a3);
    int sum=a1+a2+a3;
    if(sum==180)
        printf("Yes,Such Triangle is possible\n");
    else
        printf("Sorry,Such triangle is not possible\n");
}
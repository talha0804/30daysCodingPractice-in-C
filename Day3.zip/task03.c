#include<stdio.h>
#include<stdlib.h>
#include<time.h>
#include <stdbool.h>
bool checkEvenodd(int n){
    return (n % 2 == 0);
}
int main(){
    srand(time(0));
    int n1,n2;
    n1 = rand() % 99;
    n2 = rand() % n1;
    printf("The Two Random Numbers are=%d %d\n", n1, n2);
    int sum = n1 + n2;
    if (checkEvenodd(sum))
        printf("Their sum is Even\n");
    else
        printf("Their sum is odd\n");
    return 0;
}
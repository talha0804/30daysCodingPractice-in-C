#include<stdio.h>
int main(){
    int num;
    printf("Enter The Number:");
    scanf("%d",&num);

    if(num & 1)
        printf("%d is Odd number\n",num);
    else
        printf(" %d is Even number\n",num);
}
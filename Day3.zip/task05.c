#include <stdio.h>

int main()
{
    // ElectricityCost = Units Consumed×Unit Rate;
    //  Net Electricity Bill = ElectricityCost + Tax + GST;
    char type;
    printf("Select the Consumer type\n");
    printf("C for commercial\n");
    printf("H for home\n");
    printf("Enter consumer type:");
    scanf(" %c", &type);
    int Units_Consumed;
    float Electricity_cost;
    int tax;
    float Gst;
    float NetBill;
    printf("Enter number of units consumed: ");
    scanf("%d", &Units_Consumed);
    if (type == 'H' || type == 'h')
    {
        tax = 700;
        if (Units_Consumed <= 100)
            Electricity_cost = Units_Consumed * 11;
        else if (Units_Consumed <= 200)
            Electricity_cost = 100 * 11 + (Units_Consumed - 100) * 15;
        else
            Electricity_cost = 100 * 11 + 100 * 15 + (Units_Consumed - 200) * 20;

        Gst = Electricity_cost * 0.1;
        NetBill = Electricity_cost + Gst + tax;
    }
    else if (type == 'C' || type == 'c')
    {
        tax = 1100;
        if (Units_Consumed <= 100)
            Electricity_cost = Units_Consumed * 15;
        else if (Units_Consumed <= 200)
            Electricity_cost = 100 * 15 + (Units_Consumed - 100) * 22;
        else
            Electricity_cost = 100 * 15 + 100 * 22 + (Units_Consumed - 200) * 30;

        Gst = Electricity_cost * 0.15;
        NetBill = Electricity_cost + Gst + tax;
    }
    else
    {
        printf("Invalid consumer type entered.\n");
    }

    printf("Electricity Cost: %.3f\n", Electricity_cost);
    printf("GST             : %.3f\n", Gst);
    printf("Net Electricity Bill: %.3f\n", NetBill);

    return 0;
}

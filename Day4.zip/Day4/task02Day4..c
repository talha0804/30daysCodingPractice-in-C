#include <stdio.h>
int main()
{
    int num, f=1;
    printf("Enter The Number:");
    scanf("%d", &num);
    for (int i = 1; i <= num; i++)
    {
        f *= i;
    }

    printf("factorial=%d\n",f);
}
#include <stdio.h>
int main()
{
    int n1, n2;
    printf("Enter the first Number:");
    scanf("%d", &n1);
    printf("Enter the second Number:");
    scanf("%d", &n2);
    printf("Before Swaping:%d %d\n", n1, n2);
    n1 ^= n2;
    n2 ^= n1;
    n1 ^= n2;
    printf("After Swaping:%d %d\n", n1, n2);
}
#include <iostream>
#include <bitset>
using namespace std;
string decToHex(int num) {
    string hex;
    while (num != 0) {
        int rem = num % 16;
        if (rem < 10)
            hex.insert(0, 1, rem + '0');
        else
            hex.insert(0, 1, rem - 10 + 'A');
        num /= 16;
    }
    return hex;
}

int main() {
    cout << "Decimal  Binary       Octal  Hexadecimal" << endl;
    for (int i = 1; i <= 255; ++i) {
        cout << dec   <<  i << "        "
             << bitset<8>(i) << "       "
             << oct << i << "        "
             << decToHex(i) << endl;
    }
    return 0;
}

#include<stdio.h>
float AreaofCircle(int r){
    float pi = 3.14;
    float Area = pi * r * r;
    return Area;
}
int main(){
    int r;
    printf("Enter The radius:");
    scanf("%d", &r);
    printf("Area of The circle:%.2f", AreaofCircle(r));
}
#include <stdio.h>
#include <stdbool.h>
bool isPrime(int num)
{
    if (num <= 1)
        return false;
    for (int i = 2; i * i <= num; i++)
    {
        if (num % i == 0)
            return false;
    }
    return true;
}
int sumOfPrimes(int n)
{
    int sum = 0;
    for (int i = 2; i < n; i++)
    {
        if (isPrime(i))
            sum += i;
    }
    return sum;
}

int main()
{
    int T;
    printf("Enter the number of test cases: ");
    scanf("%d", &T);

    for (int i = 0; i < T; i++)
    {
        int N;
        printf("Enter N: ");
        scanf("%d", &N);
        printf("Sum of primes less than %d : %d\n", N, sumOfPrimes(N));
    }

    return 0;
}

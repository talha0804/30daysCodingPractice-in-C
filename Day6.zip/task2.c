#include <stdio.h>
void  Factors(int num)
{

    for (int i = 26; i>=1;i--){
        if(num%i==0)
        printf("%d ", num / i);
    }
}

int main()
{
    int num;
    printf("Enter The number:");
    scanf("%d", &num);
    Factors(num);
}